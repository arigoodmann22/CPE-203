enum ActionKind
{
    ACTIVITY, ANIMATION
}
