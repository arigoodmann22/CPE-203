import processing.core.PImage;

public interface EntityAnimation  extends Entity{

    public void scheduleActions(EventScheduler scheduler,
                                WorldModel world, ImageStore imageStore);

    public void execute(WorldModel world, ImageStore imageStore, EventScheduler scheduler);
}
