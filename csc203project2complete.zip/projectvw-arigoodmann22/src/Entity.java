import java.util.List;

import processing.core.PImage;

    public interface Entity
    {
        void nextImage();
        Point getPosition();
        void setPosition(Point p);
        int getAnimationPeriod();
        PImage getCurrentImage();




    }
