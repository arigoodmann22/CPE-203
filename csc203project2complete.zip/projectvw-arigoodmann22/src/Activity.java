public class Activity implements Action{

    private final Entity entity;
    private final WorldModel world;
    private final ImageStore imageStore;
    private final int repeatCount;

    public Activity(
            Entity entity,
            WorldModel world,
            ImageStore imageStore,
            int repeatCount)
    {
        this.entity = entity;
        this.world = world;
        this.imageStore = imageStore;
        this.repeatCount = repeatCount;
    }

    public void executeAction(EventScheduler scheduler)
    {
        if (this.entity instanceof MinerFull) {

            ((MinerFull) this.entity).execute(this.world,
                    this.imageStore, scheduler);
        }

        if (this.entity instanceof MinerNotFull) {
            ((MinerNotFull) this.entity).execute(this.world,
                    this.imageStore, scheduler);
        }

        if (this.entity instanceof Ore) {
            ((Ore) this.entity).execute(this.world,
                    this.imageStore, scheduler);
        }

        if (this.entity instanceof OreBlob) {
            ((OreBlob) this.entity).execute(this.world,
                    this.imageStore, scheduler);
        }

        if (this.entity instanceof Quake) {
            ((Quake) this.entity).execute(this.world,
                    this.imageStore, scheduler);
        }

        if (this.entity instanceof Vein) {
            ((Vein) this.entity).execute(this.world, this.imageStore, scheduler);

        }
    }

    //does this method need to be static?
    public static Activity createActivityAction(Entity entity, WorldModel world, ImageStore imageStore)
    {
        return new Activity(entity, world, imageStore, 0);
    }
}
