import processing.core.PImage;

import java.util.List;
import java.util.Random;

public class Factory {


    public static final String ORE_KEY = "ore";
    public static final String QUAKE_ID = "quake";
    public static final int QUAKE_ACTION_PERIOD = 1100;
    public static final int QUAKE_ANIMATION_PERIOD = 100;

    private static final Random rand = new Random();
    private static final String QUAKE_KEY = "quake";
    private static final int QUAKE_ANIMATION_REPEAT_COUNT = 10;


    public static MinerFull createMinerFull(
            Point position,
            String id,
            int resourceLimit,
            int actionPeriod,
            int animationPeriod,
            List<PImage> images)
    {
        return new MinerFull(id, position, images,
                resourceLimit, resourceLimit, actionPeriod,
                animationPeriod);
    }

    public static Vein createVein(
            Point position, String id, int actionPeriod, List<PImage> images) {
        return new Vein(id, position, images, 0, 0,
                actionPeriod, 0);
    }

    public static Quake createQuake(List<PImage> images, Point position)
    {
        return new Quake(QUAKE_ID, position, images, 0, 0,
                QUAKE_ACTION_PERIOD, QUAKE_ANIMATION_PERIOD);
    }

    public static OreBlob createOreBlob (String id, Point position,
                                         int actionPeriod, int animationPeriod, List<PImage > images)
    {
        return new OreBlob(id, position, images,
                0, 0, actionPeriod, animationPeriod);
    }

    public static Ore createOre(String id, Point position, int actionPeriod, List<PImage> images)
    {
        return new Ore(id, position, images, 0, 0,
                actionPeriod, 0);
    }

    public static MinerNotFull createMinerNotFull(
            Point position,
            String id,
            int resourceLimit,
            int actionPeriod,
            int animationPeriod,
            List<PImage> images)
    {
        return new MinerNotFull(id, position, images,
                resourceLimit, 0, actionPeriod, animationPeriod);
    }

    public static Obstacle createObstacle(Point position, String id,List<PImage> images)
    {
        return new Obstacle( id, position, images, 0, 0, 0,
                0);
    }

    public static Blacksmith createBlacksmith(String id,
                                              Point position, List<PImage> images)
    {
        return new Blacksmith(id, position, images, 0, 0, 0,
                0);
    }



}
