public interface Miner extends EntityAnimation {
    public Point nextPositionMiner(WorldModel world, Point destPos);
}
